exports.dashboard = (req, res) => {
  res.render('dashboard', { username: req.body.username });
};
