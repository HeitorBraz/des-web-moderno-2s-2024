const User = require('../models/user'); // Importe o modelo de usuário
const bcrypt = require('bcrypt');

// Exibe a página de login
exports.loginPage = (req, res) => {
  res.render('login', { title: 'Login' });
};

// Exibe a página de cadastro
exports.registerPage = (req, res) => {
  res.render('register', { title: 'Registrar' });
};

// Processa o cadastro de usuário
exports.register = async (req, res) => {
  const { username, password } = req.body;

  try {
    const existingUser = await User.findOne({ where: { username } });
    if (existingUser) {
      return res.render('register', { message: 'Usuário já existe!' });
    }

    const hash = await bcrypt.hash(password, 10);
    await User.create({ username, password: hash });

    res.render('login', { message: 'Cadastro bem-sucedido! Faça o login.' });
  } catch (error) {
    console.error(error);
    res.render('register', { message: 'Erro ao cadastrar.' });
  }
};

// Processa o login de usuário
exports.login = async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ where: { username } });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.render('login', { message: 'Credenciais inválidas.' });
    }

    res.render('dashboard', { title: 'Dashboard', user });
  } catch (error) {
    console.error(error);
    res.render('login', { message: 'Erro ao processar o login.' });
  }
};
