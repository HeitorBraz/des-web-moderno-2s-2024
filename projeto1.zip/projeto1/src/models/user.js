const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Definindo o modelo de usuário
const User = sequelize.define('User', {
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

// Sincroniza o modelo com o banco de dados
User.sync();

module.exports = User;
