const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController'); // Verifique o caminho

// Rota para página de login
router.get('/login', authController.loginPage); // Certifique-se de que a função loginPage existe

// Rota para a página de registro
router.get('/register', authController.registerPage); // Certifique-se de que a função registerPage existe

// Rota para processar o registro de usuário
router.post('/register', authController.register);

// Rota para processar o login de usuário
router.post('/login', authController.login);

module.exports = router;
