const { Sequelize } = require('sequelize');

// Configuração da conexão com o SQLite
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './src/database/database.sqlite' // Local onde o arquivo do banco de dados será criado
});

module.exports = sequelize;
