const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mustacheExpress = require('mustache-express');
const sequelize = require('./src/config/database');
const authRoutes = require('./src/routes/authRoutes'); // Certifique-se de que o caminho está correto

const app = express();
const PORT = 3000;

app.engine('mustache', mustacheExpress());
app.set('view engine', 'mustache');
app.set('views', path.join(__dirname, 'src/views'));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'src/public')));

// Rotas
app.use('/auth', authRoutes); // Certifique-se de que as rotas estão configuradas corretamente

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
